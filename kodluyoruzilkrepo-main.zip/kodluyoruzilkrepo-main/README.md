# Kodluyoruz Ilk Repo
Bu repo [Kodluyoruz](https://www.kodluyoruz.org/) Front-end eğitiminde oluşturduğumuz ilk repo. İçerisinde bir adet README dosyası bir ader index.html dosyası barındırıyor.

## Installation
---
Öncelikle projeyi clonelayın.

`git clone https://github.com/elifbeyza-polat/kodluyoruzilkrepo.git`

## USAGE
---
Projeyi cloneladıktan sonra Visual Studio Code programında açın.
```
cd kodluyoruzilkrepo
code .
```

## CONTRIBUTING
---
Pull requestler kabul edilir. Büyük değişiklikler için, lütfen önce neyi değiştirmek istediğinizi tartışmak için bir konu açınız.

## LICENCE
---
[MIT](https://choosealicense.com/licenses/mit/)


